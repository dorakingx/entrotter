"""Actual pinned CLI invocation with an explicit offline network/subprocess guard."""
import sys, socket, subprocess, json,hashlib
from pathlib import Path
q=Path(__file__).resolve().parent
workspace=q.parents[2]
expected={'entrotter-cli':workspace/'.worktrees/cli-bounded','entrotter-sdk':workspace/'sdk-python'}
for name,path in expected.items():assert (Path.cwd()/name).resolve()==path.resolve(),name
attempts=[]
def deny(event,args):
 if event in {'socket.connect','socket.connect_ex','socket.getaddrinfo','subprocess.Popen','os.system','os.posix_spawn'}:
  attempts.append(event)
  raise RuntimeError('Offline inspection guard: '+event)
sys.addaudithook(deny)
from entrotter_cli.main import main
sys.argv=['entrotter-cli','inspect','./aave-borrow-actions.json','--format','text']
try:code=main()
finally:
 modules={name:{'path':str(Path(m.__file__).resolve()),'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for name,m in sys.modules.items() if name.startswith(('entrotter_cli','entrotter_sdk')) and getattr(m,'__file__',None)}
 (q/'cli-network-guard.json').write_text(json.dumps({'blocked_events':attempts,'aliases':{name:str((Path.cwd()/name).resolve()) for name in expected},'module_origins':modules,'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Python audit hook rejects audited outbound DNS/connect and child processes; not a universal OS sandbox; no engine execution'})+'\n')
sys.exit(code)
