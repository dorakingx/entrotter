import json,subprocess,hashlib,shutil
from pathlib import Path
q=Path(__file__).resolve().parent
probe='/opt/homebrew/bin/ffprobe';ffmpeg='/opt/homebrew/bin/ffmpeg'
t=json.loads((q/'audio/frame-timeline.json').read_text());offset=next(s['start'] for s in t['scenes'] if s['id']=='download')
firsts=list((q/'capture/raw').glob('*.webm'));assert len(firsts)==1
first=firsts[0];second=q/'capture-resumed/clean-capture.webm';assert second.exists()
def inspect(p):
 d=json.loads(subprocess.check_output([probe,'-v','error','-show_format','-show_streams','-of','json',str(p)]))
 raw=subprocess.check_output([ffmpeg,'-v','error','-nostdin','-i',str(p),'-vf','crop=8:8:1592:892,scale=1:1','-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','-'])
 stream=next(s for s in d['streams'] if s['codec_type']=='video');a,b=map(int,stream['r_frame_rate'].split('/'));fps=a/b
 pixels=[tuple(raw[i:i+3]) for i in range(0,len(raw),3)]
 ids=[i for i,(r,g,b) in enumerate(pixels) if r>150 and g<80 and b>150];assert ids
 begin=ids[0];assert ids==list(range(begin,len(pixels))), 'Marker should remain after exact onset'
 result=dict(path=str(p.relative_to(q)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),probe=d,frames=len(pixels),marker_frame=begin,marker_seconds=begin/fps,fps=fps,pixel_rgb=pixels[begin],clock='First actually encoded magenta 8px sync marker frame; frame quantization <=1/25second')
 return result
one=inspect(first);two=inspect(second)
assert float(one['probe']['format']['duration'])>=one['marker_seconds']+offset
assert float(two['probe']['format']['duration'])>=two['marker_seconds']+t['duration']-offset-.05
out=q/'projects/entrotter-aave-demo/deliverables';out.mkdir(parents=True,exist_ok=True)
master=out/'entrotter-aave-clean.mp4'
filters=f"[0:v]trim=start={one['marker_seconds']}:duration={offset},setpts=PTS-STARTPTS[v0];[1:v]trim=start={two['marker_seconds']}:duration={t['duration']-offset},setpts=PTS-STARTPTS[v1];[v0][v1]concat=n=2:v=1:a=0,format=yuv420p[v];[2:a]loudnorm=I=-16:TP=-1.5:LRA=11[a]"
argv=[ffmpeg,'-v','warning','-nostdin','-y','-i',str(first),'-i',str(second),'-i',str(q/'audio/demo.wav'),'-filter_complex',filters,'-map','[v]','-map','[a]','-c:v','libx264','-preset','medium','-crf','20','-r','25','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-ar','48000','-t',str(t['duration']),'-movflags','+faststart',str(master)]
proof=dict(status='render requested',inputs=[one,two],audio_sha256=hashlib.sha256((q/'audio/demo.wav').read_bytes()).hexdigest(),argv=argv,cuts=[dict(input=one['path'],source_start=one['marker_seconds'],source_duration=offset,timeline_start=0),dict(input=two['path'],source_start=two['marker_seconds'],source_duration=t['duration']-offset,timeline_start=offset)],scope='First six valid scenes retained from terminal1 selector-timeout capture; failed download onward excluded. Corrected last five scenes from terminal0 resumed capture. No original signed transaction replay/new EVM. Clean master has no captions.')
(q/'render.json').write_text(json.dumps(proof,indent=2)+'\n')
with (q/'encode.stdout').open('wb') as so,(q/'encode.stderr').open('wb') as se:r=subprocess.run(argv,stdout=so,stderr=se)
proof['returncode']=r.returncode;assert r.returncode==0
proof['status']='PASS clean render';proof['output']=dict(path=str(master.relative_to(q)),bytes=master.stat().st_size,sha256=hashlib.sha256(master.read_bytes()).hexdigest(),probe=json.loads(subprocess.check_output([probe,'-v','error','-show_format','-show_streams','-of','json',str(master)])))
(q/'render.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':proof['status'],'markers':[one['marker_seconds'],two['marker_seconds']],'duration':proof['output']['probe']['format']['duration'],'bytes':master.stat().st_size}))
