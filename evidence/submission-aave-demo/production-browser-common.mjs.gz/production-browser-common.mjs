import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
export const q=resolve(import.meta.dirname);
export const workspace=resolve(q,'../../..');
export const site=resolve(workspace,'entrotter.github.io');
export const require=createRequire(resolve(site,'package.json'));
export const {chromium}=require('playwright');
export const hash=b=>createHash('sha256').update(b).digest('hex');
export const verify=(repo,head)=>{assert.equal(execFileSync('git',['-C',repo,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),head);execFileSync('git',['-C',repo,'diff','--quiet']);execFileSync('git',['-C',repo,'diff','--cached','--quiet']);};
export async function host(){
 const tracked=new Set(execFileSync('git',['-C',site,'ls-files'],{encoding:'utf8'}).trim().split('\n'));
 const served=new Map();const faults=[];
 const server=createServer(async(req,res)=>{
  try{
   assert.equal(req.method,'GET');const url=new URL(req.url,'http://127.0.0.1');let path;
   if(url.pathname==='/')path=resolve(q,'studio.html');
   else if(url.pathname.startsWith('/site/')){const name=decodeURIComponent(url.pathname.slice(6))||'index.html';assert(tracked.has(name));path=resolve(site,name);}
   else throw Error('Not allowlisted');
   const raw=await readFile(path);served.set(url.pathname,hash(raw));
   const types={'.html':'text/html','.mjs':'text/javascript','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.webp':'image/webp'};
   res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'no-store'}).end(raw);
  }catch(e){faults.push(String(e));res.writeHead(404).end('Not found');}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));return {server,url:`http://127.0.0.1:${server.address().port}`,served,faults};
}
