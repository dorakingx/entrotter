import os,json,subprocess,hashlib,time
from pathlib import Path
q=Path(__file__).resolve().parent;w=q.parents[2];work=q/'cli-work'
env=dict(os.environ,PYTHONPATH='entrotter-cli/src:entrotter-sdk/src');env.pop('PYTHONOPTIMIZE',None)
argv=[str(w/'.tools/quality-venv/bin/python'),str(q/'inspect-offline.py')]
start=time.monotonic();p=subprocess.run(argv,cwd=work,env=env,capture_output=True,timeout=10)
(q/'cli-origin.stdout').write_bytes(p.stdout);(q/'cli-origin.stderr').write_bytes(p.stderr)
guard=json.loads((q/'cli-network-guard.json').read_text())
proof=dict(returncode=p.returncode,argv=argv,cwd=str(work),PYTHONPATH=env['PYTHONPATH'],elapsed_seconds=time.monotonic()-start,guard=guard,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest(),scope='Focused actual offline CLI re-execution to resolve missing original module-origin evidence; current guarded aliases checked within child. Earlier capture CLI origins were not exported; whole outputs match.')
(q/'cli-origin-review.json').write_text(json.dumps(proof,indent=2)+'\n')
assert p.returncode==0 and not p.stderr and guard['blocked_events']==[]
assert p.stdout==(q/'capture-resumed/cli.stdout').read_bytes()
refs={w/'.worktrees/cli-bounded':'169b759aff9280ce44fb0d15569c7ae0a4a40889',w/'sdk-python':'ba4af512784119f23b6dea63fd24c7f5d1fdde44'}
origins={}
for name,info in guard['module_origins'].items():
 path=Path(info['path']); repo=next(r for r in refs if path.is_relative_to(r));rel=str(path.relative_to(repo));raw=subprocess.check_output(['git','-C',str(repo),'show',refs[repo]+':'+rel]);assert hashlib.sha256(raw).hexdigest()==info['sha256'];origins[name]=dict(repo=str(repo.name),ref=refs[repo],path=rel,sha256=info['sha256'])
proof.update(status='PASS guarded current CLI origin and byte equality',immutable_origins=origins,modules=len(origins));(q/'cli-origin-review.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof['status'],len(origins),'actual module files')
