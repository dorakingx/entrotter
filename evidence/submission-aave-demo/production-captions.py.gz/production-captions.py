"""Draft sentence captions derived from the actual PCM clock; ASR differences remain explicit."""
import json,re,wave,array,math
from pathlib import Path
q=Path(__file__).resolve().parent
t=json.loads((q/'audio/frame-timeline.json').read_text());asr=json.loads((q/'asr.json').read_text()); rows=[]
num={'twenty':'20','ten':'10','nine':'9','one':'1'}
def normalize(text):
 tokens=re.findall(r'[a-z0-9]+',text.lower().replace('on-chain','onchain'))
 return [num.get(x,x) for x in tokens]
for cue,result in zip(t['captions'],asr['results'],strict=True):
 assert cue['take']==result['take'] and cue['text']==result['expected_text']
 recognized=''.join(x['text'] for x in result['segments'])
 with wave.open(str(q/'audio'/cue['take'])) as w:
  sr=w.getframerate();n=w.getnframes();samples=array.array('h',w.readframes(n))
 step=round(sr*.01);active=[]
 for start in range(0,n,step):
  block=samples[start:start+step]
  rms=math.sqrt(sum(x*x for x in block)/len(block))/32768
  if rms>=10**(-45/20):active.append((start,min(n,start+step)))
 assert active
 start=cue['start']+active[0][0]/sr;end=cue['start']+active[-1][1]/sr
 rows.append(dict(start=start,end=end,text=cue['text'],scene=cue['scene'],take=cue['take'],pcm_window_seconds=.01,threshold_dbfs=-45,asr_text=recognized,normalized_word_match=normalize(recognized)==normalize(cue['text']),status='Draft: authored sentence span from actual PCM activity; pronunciation/ASR differences require human review'))
assert len(rows)==23
out=dict(status='DRAFT captions and pronunciation review pending',clock=t['clock'],normalization='case/punctuation; on-chain=>onchain; written one/nine/ten/twenty=>1/9/10/20',captions=rows,matched_cues=sum(r['normalized_word_match'] for r in rows),unmatched_cues=[r['take'] for r in rows if not r['normalized_word_match']],scope='Authored text is retained, not substituted into ASR words by index. Sentence timing uses verified PCM activity; no claim of complete ASR agreement or human listening.')
(q/'caption-draft.json').write_text(json.dumps(out,indent=2)+'\n')
def stamp(s,vtt):
 ms=round(s*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000)
 return f'{h:02}:{m:02}:{sec:02}{"." if vtt else ","}{ms:03}'
for fmt in ['srt','vtt']:
 body='WEBVTT\n\nNOTE Draft authored captions. Pronunciation review pending.\n\n' if fmt=='vtt' else ''
 for i,c in enumerate(rows,1):body+=f'{i}\n{stamp(c["start"],fmt=="vtt")} --> {stamp(c["end"],fmt=="vtt")}\n{c["text"]}\n\n'
 (q/f'caption-draft.{fmt}').write_text(body)
print(out['status'],out['matched_cues'],'matched cues;',len(out['unmatched_cues']),'unmatched')
