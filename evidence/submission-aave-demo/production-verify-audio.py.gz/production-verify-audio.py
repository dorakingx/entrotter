import json,wave,hashlib
from pathlib import Path
q=Path(__file__).resolve().parent
scenes=json.loads((q/'scenes.json').read_text())['demo']
timeline=json.loads((q/'audio/demo-timeline.json').read_text())
chunks=[]; takes=[]; frame_cursor=22050; captions=[]; events=[]
for s in scenes:
 start=frame_cursor
 for i,text in enumerate(s['narration']):
  p=q/'audio'/f"demo-{s['id']}-{i}.wav"
  with wave.open(str(p)) as w:
   assert (w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getcomptype())==(1,2,22050,'NONE')
   n=w.getnframes(); raw=w.readframes(n); assert len(raw)==n*2 and n>0
  captions.append(dict(start=frame_cursor/22050,end=(frame_cursor+n)/22050,text=text,scene=s['id'],take=p.name))
  takes.append(dict(path=str(p.relative_to(q)),bytes=p.stat().st_size,frames=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
  gap=round(22050*.45); chunks.extend([raw,b'\0\0'*gap]); frame_cursor+=n+gap
 gap=round(22050*.5); chunks.append(b'\0\0'*gap); frame_cursor+=gap
 events.append(dict(id=s['id'],label=s['label'],narration=s['narration'],start=start/22050,end=frame_cursor/22050))
expected=b'\0\0'*22050+b''.join(chunks)+b'\0\0'*22050
p=q/'audio/demo.wav'
with wave.open(str(p)) as w:
 actual=w.readframes(w.getnframes()); assert actual==expected
 assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,22050)
 duration=w.getnframes()/22050
assert len(captions)==23 and duration<180
assert [c['text'] for c in timeline['captions']]==[c['text'] for c in captions]
assert max(abs(a[k]-b[k]) for a,b in zip(captions,timeline['captions']) for k in ['start','end'])<.001
precise=dict(scenes=events,captions=captions,duration=duration,clock='actual integer PCM frame positions at 22050Hz')
(q/'audio/frame-timeline.json').write_text(json.dumps(precise,indent=2)+'\n')
originals=json.loads((q/'original-media-sha256.json').read_text())
print('original manifest schema',type(originals).__name__)
proof=dict(status='PASS completed audio files only',producer_status='terminal134 with recursive_mutex exception; cause unproven; not a successful producer exit',takes=takes,combined=dict(bytes=p.stat().st_size,frames=len(expected)//2,duration=duration,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),scope='all 23 PCM payloads exactly reassembled into combined WAV; authored inventory and sample frame timing verified. Audible correctness requires transcription/listening.')
(q/'audio-file-review.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['status','producer_status','combined']}))
