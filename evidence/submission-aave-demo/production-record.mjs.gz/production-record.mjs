// Continuous capture of current pinned viewer, native copy/download, and real offline CLI output.
import {q,workspace,site,chromium,host,verify,hash} from './browser-common.mjs';
import {readFile,writeFile,mkdir,symlink,realpath} from 'node:fs/promises';
import {resolve} from 'node:path';import {execFileSync,spawn} from 'node:child_process';import assert from 'node:assert/strict';
const pins={viewer:'ad697dc5c7c9506ed8ec54386da727b0ef2f0b81',cli:'169b759aff9280ce44fb0d15569c7ae0a4a40889',sdk:'ba4af512784119f23b6dea63fd24c7f5d1fdde44'};
const cli=resolve(workspace,'.worktrees/cli-bounded'),sdk=resolve(workspace,'sdk-python');
verify(site,pins.viewer);verify(cli,pins.cli);verify(sdk,pins.sdk);
const timeline=JSON.parse(await readFile(resolve(q,'audio/frame-timeline.json'),'utf8'));
const original=await readFile(resolve(site,'reports/aave-borrow-actions.json'));
assert.equal(original.length,59506);assert.equal(hash(original),'e2db6ee04f2642e7e75ac53e8ad6212cd68b2ae4aab0ca7a4e06063f5f435622');
const offset=process.argv[2]==='download'?timeline.scenes.find(s=>s.id==='download').start:Number(process.argv[2]||0);assert([0,timeline.scenes.find(s=>s.id==='download').start].includes(offset));
const out=resolve(q,offset?'capture-resumed':'capture');await mkdir(out,{recursive:true});
const work=resolve(q,'cli-work');await mkdir(work,{recursive:true});
for(const[name,path]of [['entrotter-cli',cli],['entrotter-sdk',sdk]]){try{await symlink(path,resolve(work,name),'dir');}catch(e){if(e.code!=='EEXIST')throw e;}assert.equal(await realpath(resolve(work,name)),await realpath(path));}
const hostState=await host();let browser,context;
const requests=[],responses=[],errors=[],events=[],shots=[],observed={};let stdout;
const save=async(name,obj)=>writeFile(resolve(out,name),JSON.stringify(obj,null,2)+'\n');
try{
 browser=await chromium.launch({headless:true});context=await browser.newContext({viewport:{width:1600,height:900},deviceScaleFactor:1,permissions:['clipboard-read','clipboard-write'],acceptDownloads:true,recordVideo:{dir:resolve(out,'raw'),size:{width:1600,height:900}}});
 const page=await context.newPage();page.on('request',r=>requests.push({url:r.url(),method:r.method()}));page.on('response',r=>responses.push({url:r.url(),status:r.status()}));page.on('pageerror',e=>errors.push(e.message));
 await page.goto(hostState.url);const f=page.frameLocator('#product');await page.evaluate(()=>studio.mode('product','ARCHIVED-STATE RECORDING · CURRENT OFFLINE INSPECTION'));
 await f.locator('details.archive > summary').click();await f.locator('#scenario').selectOption('aave-borrow-actions');await f.locator('#hash').filter({hasText:'728cfe26dcd40ed9bc08d28c5d8c9a088a7a8b6ad22b83a07285af9084175b00'}).waitFor();
 assert.equal(await f.locator('#balance-rows tr').count(),16);assert.equal(await f.locator('#evm-traces tr').count(),10);assert.equal(await f.locator('#agent-rows tr').count(),1);
 observed.balance_rows=await f.locator('#balance-rows tr').allTextContents();observed.action_rows=await f.locator('#evm-traces tr').allTextContents();observed.agent_row=await f.locator('#agent-rows').innerText();observed.provenance=await f.locator('#agent-provenance').innerText();
 assert(observed.agent_row.includes('hold')&&observed.agent_row.includes('noop'));assert(observed.provenance.includes('preflight-risk-v1'));
 await f.locator('h1').evaluate(e=>e.scrollIntoView({block:'start'}));
 await page.evaluate(()=>{const m=document.createElement('div');m.id='sync-marker';Object.assign(m.style,{position:'fixed',bottom:'0',right:'0',width:'8px',height:'8px',background:'#000',zIndex:100});document.body.append(m);});
 const shot=async name=>{await page.screenshot({path:resolve(out,`${name}.png`)});shots.push(name);};
 const start=performance.now();await page.evaluate(()=>{document.querySelector('#sync-marker').style.background='#ff00ff';});
 let index=-1,subEvent=false;
 while((performance.now()-start)/1000<timeline.duration-offset+.35){
  const seconds=(performance.now()-start)/1000+offset;const next=timeline.scenes.findIndex(s=>seconds>=s.start&&seconds<s.end);
  if(next>=0&&next!==index){index=next;subEvent=false;const s=timeline.scenes[index];const event={scene:s.id,started:seconds};events.push(event);console.log(s.id,seconds.toFixed(3));await page.evaluate(label=>studio.mode('product',label),s.label);
   if(s.id==='intro')await f.locator('h1').evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='record')await f.locator('#scenario').evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='setup')await f.locator('#evm-details').evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='decision'||s.id==='final')await f.getByText('Supplied actions on isolated local forks',{exact:true}).evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='balances')await f.locator('#evm-details').evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='download'){
    await f.locator('#download').evaluate(e=>e.scrollIntoView({block:'start'}));
    const pending=page.waitForEvent('download');await f.locator('#download').click();const download=await pending;
    assert.equal(download.suggestedFilename(),'aave-borrow-actions.json');await download.saveAs(resolve(work,'aave-borrow-actions.json'));
    const downloaded=await readFile(resolve(work,'aave-borrow-actions.json'));assert.deepEqual(downloaded,original);observed.download={filename:download.suggestedFilename(),bytes:downloaded.length,sha256:hash(downloaded)};
    await f.locator('#cli-recipe > summary').click();await f.locator('#cli-setup').evaluate(e=>e.scrollIntoView({block:'start'}));
   }
   if(s.id==='copy'){
    const text=await f.locator('#cli-command').innerText();assert.equal(text,'PYTHONPATH=entrotter-cli/src:entrotter-sdk/src python3 -m entrotter_cli inspect ./aave-borrow-actions.json --format text');
    await f.locator('#cli-copy-command').focus();await page.keyboard.press('Enter');await f.locator('#cli-copy-status').filter({hasText:'Inspection command copied.'}).waitFor();
    const clipboard=await page.evaluate(()=>navigator.clipboard.readText());assert.equal(clipboard,text);observed.command_copy={payload:text,readback:clipboard,activation:'native keyboard Enter',focus:await f.locator('#cli-copy-command').evaluate(e=>e===document.activeElement)};
    const argv=[resolve(q,'inspect-offline.py')];const python=resolve(workspace,'.tools/quality-venv/bin/python');const env={...process.env,PYTHONPATH:'entrotter-cli/src:entrotter-sdk/src'};delete env.PYTHONOPTIMIZE;
    const begin=performance.now();const proc=spawn(python,argv,{cwd:work,env,stdio:['ignore','pipe','pipe']});let raw='',err='';proc.stdout.on('data',b=>raw+=b);proc.stderr.on('data',b=>err+=b);
    const timeout=setTimeout(()=>proc.kill('SIGTERM'),10000);const code=await new Promise((r,j)=>{proc.on('error',j);proc.on('close',r);});clearTimeout(timeout);
    await writeFile(resolve(out,'cli.stdout'),raw);await writeFile(resolve(out,'cli.stderr'),err);observed.cli={code,elapsed_seconds:(performance.now()-begin)/1000,executable:python,argv,cwd:work,PYTHONPATH:env.PYTHONPATH,stdout_bytes:Buffer.byteLength(raw),stdout_sha256:hash(Buffer.from(raw)),stderr_bytes:Buffer.byteLength(err),network_guard:JSON.parse(await readFile(resolve(q,'cli-network-guard.json'),'utf8')),scope:'Actual pinned CLI main with fixed argv, offline guard, aliases to selected existing sources; prior clean clone setup not rerun'};
    await save('cli-process.json',observed.cli);assert.equal(code,0);assert.equal(err,'');assert.deepEqual(Buffer.from(raw),execFileSync('git',['-C',cli,'show',`${pins.cli}:tests/data/aave-borrow-result.txt`]));assert.deepEqual(observed.cli.network_guard.blocked_events,[]);stdout=raw;
   }
   if(s.id==='cli'){assert(stdout);await page.evaluate(({label,text})=>{studio.mode('console',label);studio.output(text);document.querySelector('#output').scrollTop=0;},{label:s.label,text:stdout});}
   if(s.id==='limit'){const summary=f.getByText('Assumptions and limits',{exact:true});await summary.evaluate(e=>e.scrollIntoView({block:'start'}));}
   if(s.id==='end')await page.evaluate(()=>studio.slide({id:'close',eyebrow:'REPRODUCE / REVIEW / CONTRIBUTE',title:'Bring one decision\nyou need to explain.',body:'entrotter.github.io · github.com/entrotter',lines:['Same inputs · baseline revert and candidate hold','Exact units · recorded receipts · pinned inspection','Review branches · main, Pages and submission pending']},10));
   event.ready=(performance.now()-start)/1000+offset;await shot(s.id);
  }
  const s=timeline.scenes[index];if(s&&!subEvent&&seconds>=timeline.captions.filter(c=>c.scene===s.id)[1]?.start){subEvent=true;
   if(s.id==='decision')await f.locator('#agent-heading').evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='balances')await f.locator('#balance-rows tr').nth(10).evaluate(e=>e.scrollIntoView({block:'start'}));
   if(s.id==='download'){await f.locator('#cli-copy-setup').focus();await page.keyboard.press('Enter');await f.locator('#cli-copy-status').filter({hasText:'CLI setup copied.'}).waitFor();const payload=await f.locator('#cli-setup').innerText();const readback=await page.evaluate(()=>navigator.clipboard.readText());assert.equal(payload,readback);assert(payload.includes(pins.cli)&&payload.includes(pins.sdk));observed.setup_copy={payload,readback,activation:'native keyboard Enter',scope:'Actual clipboard only; setup clone commands not executed this turn'};}
   if(s.id==='cli')await page.evaluate(()=>{const e=document.querySelector('#output');e.scrollTop=e.scrollHeight;});
   if(['decision','balances','download','cli'].includes(s.id)){events.push({scene:s.id+'-detail',ready:(performance.now()-start)/1000+offset});await shot(s.id+'-detail');}
  }
  await new Promise(r=>setTimeout(r,65));
 }
 const captureWall=(performance.now()-start)/1000;
 assert.equal(timeline.scenes.filter(s=>s.end>offset).length,events.filter(e=>e.started!==undefined).length);assert.equal(errors.length,0);assert.equal(hostState.faults.length,0);assert(requests.every(r=>r.url.startsWith(hostState.url+'/')&&r.method==='GET'));assert.equal(responses.length,requests.length);assert(responses.every(r=>r.status===200));
 verify(site,pins.viewer);verify(cli,pins.cli);verify(sdk,pins.sdk);
 await save('capture.json',{status:'PASS actual capture',browser:browser.version(),pins,timeline_duration:timeline.duration,offset_seconds:offset,capture_wall_seconds:captureWall,events,shots,requests,responses,errors,observed,served_sha256:Object.fromEntries(hostState.served),scope:'Continuous real viewer at pinned source; actual native copy/download and read-only CLI. Previously recorded archived-state actions; no new EVM/RPC/model run; clean capture has no burned captions.'});
 const video=page.video();await context.close();context=null;await video.saveAs(resolve(out,'clean-capture.webm'));
} catch(e){await save('failure.json',{error:String(e),events,requests,responses,errors,observed});throw e;}
finally{if(context)await context.close();if(browser)await browser.close();await new Promise(r=>hostState.server.close(r));}
