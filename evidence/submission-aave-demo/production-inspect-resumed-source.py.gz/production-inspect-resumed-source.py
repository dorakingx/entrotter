"""Actual pinned CLI invocation with an explicit offline network/subprocess guard."""
import sys, socket, subprocess, json
from pathlib import Path
q=Path(__file__).resolve().parent
attempts=[]
def deny(event,args):
 if event in {'socket.connect','socket.connect_ex','socket.getaddrinfo','subprocess.Popen','os.system','os.posix_spawn'}:
  attempts.append(event)
  raise RuntimeError('Offline inspection guard: '+event)
sys.addaudithook(deny)
from entrotter_cli.main import main
sys.argv=['entrotter-cli','inspect','./aave-borrow-actions.json','--format','text']
try:code=main()
finally:(q/'cli-network-guard.json').write_text(json.dumps({'blocked_events':attempts,'scope':'Python audit hook rejects outbound DNS/connect and child processes; no engine execution'})+'\n')
sys.exit(code)
