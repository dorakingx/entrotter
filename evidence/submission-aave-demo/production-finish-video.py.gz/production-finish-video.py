import subprocess,json,hashlib
from pathlib import Path
q=Path(__file__).resolve().parent;out=q/'projects/entrotter-aave-demo/deliverables';clean=out/'entrotter-aave-clean.mp4';master=out/'entrotter-demo-aave-review.mp4'
ff='/opt/homebrew/bin/ffmpeg';fp='/opt/homebrew/bin/ffprobe';t=json.loads((q/'audio/frame-timeline.json').read_text())
assert json.loads((q/'caption-render.json').read_text())['status']=='PASS rendered draft caption geometry'
argv=[ff,'-v','warning','-nostdin','-y','-i',str(clean),'-f','concat','-safe','0','-i',str(q/'caption-cards.ffconcat'),'-filter_complex','[0:v][1:v]overlay=0:762:eof_action=repeat:shortest=0:format=auto,format=yuv420p[v]','-map','[v]','-map','0:a:0','-c:v','libx264','-preset','medium','-crf','20','-r','25','-pix_fmt','yuv420p','-c:a','copy','-t',str(t['duration']),'-movflags','+faststart',str(master)]
(q/'caption-encode-argv.json').write_text(json.dumps(argv,indent=2)+'\n')
with (q/'caption-encode.stdout').open('wb') as so,(q/'caption-encode.stderr').open('wb') as se:r=subprocess.run(argv,stdout=so,stderr=se)
assert r.returncode==0
probe=json.loads(subprocess.check_output([fp,'-v','error','-show_format','-show_streams','-of','json',str(master)]));streams=probe['streams'];v=[s for s in streams if s['codec_type']=='video'];a=[s for s in streams if s['codec_type']=='audio'];assert len(v)==len(a)==1
assert v[0]['codec_name']=='h264' and (v[0]['width'],v[0]['height'])==(1600,900) and v[0]['pix_fmt']=='yuv420p' and v[0]['r_frame_rate']=='25/1'
assert a[0]['codec_name']=='aac' and a[0]['sample_rate']=='48000';assert float(probe['format']['duration'])<180
with (q/'final-decode.stderr').open('wb') as se:r=subprocess.run([ff,'-v','error','-xerror','-nostdin','-i',str(master),'-f','null','-'],stdout=subprocess.DEVNULL,stderr=se)
assert r.returncode==0 and not (q/'final-decode.stderr').read_bytes()
with (q/'final-loudness.stderr').open('wb') as se:r=subprocess.run([ff,'-hide_banner','-nostdin','-i',str(master),'-af','ebur128=peak=true','-vn','-f','null','-'],stdout=subprocess.DEVNULL,stderr=se)
assert r.returncode==0
frames=q/'final-frames';frames.mkdir(exist_ok=True)
times=[0.5,4,14,25,37,41,53,64,68,75.5,82,87,98,102,113,127,136.8,138.2]
for i,seconds in enumerate(times):
 p=frames/f'{i:02}-{seconds:g}.png';subprocess.run([ff,'-v','error','-nostdin','-y','-ss',str(seconds),'-i',str(master),'-frames:v','1',str(p)],check=True)
originals=json.loads((q/'original-media-sha256.json').read_text());root=q.parents[1]
for name,sha in originals.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
proof=dict(status='PASS media format and full decode; caption/pronunciation review pending',output=dict(path=str(master.relative_to(q)),bytes=master.stat().st_size,sha256=hashlib.sha256(master.read_bytes()).hexdigest(),probe=probe),clean_master_sha256=hashlib.sha256(clean.read_bytes()).hexdigest(),caption_status='DRAFT authored captions; 14 normalized ASR matches and9 differences; no human listening approval',decode=dict(returncode=0,stderr_bytes=0),loudness_returncode=0,original_media_preserved=originals,frames=[dict(time=s,path=str((frames/f'{i:02}-{s:g}.png').relative_to(q)),sha256=hashlib.sha256((frames/f'{i:02}-{s:g}.png').read_bytes()).hexdigest()) for i,s in enumerate(times)],scope='New extra review cut, not replacement/owner-approved final submission. Clean master retained. Current viewer and offline CLI; previously recorded archived-state action execution, not new EVM/RPC/model run.')
(q/'final-video-review.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'status':proof['status'],'duration':probe['format']['duration'],'bytes':master.stat().st_size,'sha256':proof['output']['sha256']}))
