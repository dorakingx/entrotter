import json,subprocess,hashlib
from pathlib import Path
import numpy as np
def pixels(path):
 raw=subprocess.check_output(['/opt/homebrew/bin/ffmpeg','-v','error','-nostdin','-i',str(path),'-f','rawvideo','-pix_fmt','rgb24','-'])
 assert len(raw)==1600*138*3
 return np.frombuffer(raw,dtype=np.uint8).astype(np.int16)
q=Path(__file__).resolve().parent;master=q/'projects/entrotter-aave-demo/deliverables/entrotter-demo-aave-review.mp4';d=json.loads((q/'caption-draft.json').read_text());out=q/'caption-frames';out.mkdir(exist_ok=True);rows=[]
for i,c in enumerate(d['captions']):
 seconds=(c['start']+c['end'])/2;p=out/f'cue-{i:02}.png';subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-nostdin','-y','-ss',str(seconds),'-i',str(master),'-vf','crop=1600:138:0:762','-frames:v','1',str(p)],check=True)
 actual=pixels(p);card=pixels(q/'caption-cards'/f'cue-{i:02}.png');delta=np.abs(actual-card).astype(np.float64);rms=float(np.sqrt(np.mean(delta*delta)));mean=float(np.mean(delta))
 rows.append(dict(cue=i,seconds=seconds,text=c['text'],mean_absolute_rgb_difference=mean,rms_rgb_difference=rms,decoded_frame_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 assert rms<6 and mean<2,(i,rms,mean)
proof=dict(status='PASS all23 actual encoded caption midpoints visually match rendered draft cards within declared compression thresholds',rms_threshold=6,mean_absolute_threshold=2,frames=rows,scope='Encoded word inventory/geometry and timing at actual PCM cue midpoints, not pronunciation or human word approval; captions remain draft')
(q/'encoded-caption-review.json').write_text(json.dumps(proof,indent=2)+'\n');print('All23 actual encoded cue midpoints pass; maxRMS',max(r['rms_rgb_difference'] for r in rows))
