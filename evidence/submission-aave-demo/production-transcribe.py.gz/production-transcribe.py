import json,hashlib,importlib.metadata,time,subprocess,wave
import numpy as np
from pathlib import Path
from faster_whisper import WhisperModel
q=Path(__file__).resolve().parent
cache=q.parents[2]/'.tools/aave-caption-models'
start=time.monotonic()
model=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,download_root=str(cache))
results=[]
for caption in json.loads((q/'audio/frame-timeline.json').read_text())['captions']:
 p=q/'audio'/caption['take']
 resampled=p.with_suffix('.16k.wav')
 subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-nostdin','-y','-i',str(p),'-ac','1','-ar','16000',str(resampled)],check=True)
 with wave.open(str(resampled)) as w:
  assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000)
  pcm=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768.0
 segments, info=model.transcribe(pcm,beam_size=5,language='en',word_timestamps=True,condition_on_previous_text=False,vad_filter=False)
 rows=[]
 for seg in segments:
  rows.append(dict(start=seg.start,end=seg.end,text=seg.text,words=[dict(start=w.start,end=w.end,word=w.word,probability=w.probability) for w in seg.words]))
 result=dict(take=caption['take'],expected_text=caption['text'],segments=rows)
 results.append(result)
 (q/'asr-partial.json').write_text(json.dumps(results,indent=2)+'\n')
 print(caption['take'],''.join(x['text'] for x in rows),flush=True)
files=[dict(path=str(p.relative_to(cache)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(cache.rglob('*')) if p.is_file()]
proof=dict(model='small.en',audio_input='actual WAV PCM resampled by ffmpeg to 16000Hz, normalized float32 ndarray; avoids incompatible PyAV19 metadata_errors API',device='cpu',compute_type='int8',cpu_threads=2,elapsed_seconds=time.monotonic()-start,packages={x:importlib.metadata.version(x) for x in ['faster-whisper','ctranslate2','av','huggingface-hub']},model_files=files,results=results,scope='ASR of actual WAV takes, independently recognized text; ASR is not human audio approval')
(q/'asr.json').write_text(json.dumps(proof,indent=2)+'\n')
