// Render authored draft caption cards in Chromium. This is not an ASR-word correction by index.
import {q,chromium,hash} from './browser-common.mjs';import {resolve} from 'node:path';import {readFile,writeFile,mkdir} from 'node:fs/promises';import assert from 'node:assert/strict';
const data=JSON.parse(await readFile(resolve(q,'caption-draft.json'),'utf8'));const duration=JSON.parse(await readFile(resolve(q,'audio/frame-timeline.json'),'utf8')).duration;
const out=resolve(q,'caption-cards');await mkdir(out,{recursive:true});let browser;
try{
 browser=await chromium.launch({headless:true});const ctx=await browser.newContext({viewport:{width:1600,height:138},deviceScaleFactor:1});const p=await ctx.newPage();const requests=[];p.on('request',r=>requests.push(r.url()));
 await p.setContent(`<!doctype html><html lang="en"><meta charset="utf-8"><style>*{box-sizing:border-box}html,body{margin:0;width:1600px;height:138px;background:#191224;font-family:Arial,Helvetica,sans-serif}footer{height:138px;border-top:1px solid #493158;padding:10px 70px 10px;display:flex;flex-direction:column;justify-content:center}#caption{font-size:28px;line-height:1.3;margin:0;height:78px;width:1460px;color:#fff;display:flex;align-items:center}#meta{color:#aaa0ba;display:flex;justify-content:space-between;font-size:12px;letter-spacing:1px;margin-top:7px}</style><footer><p id="caption"></p><div id="meta"><span>OPEN SOURCE · RECORDED ACTIONS · OFFLINE INSPECTION</span><span>SYNTHETIC NARRATION · CAPTION DRAFT</span></div></footer>`);
 const cards=[];
 for(let i=-1;i<data.captions.length;i++){
  const text=i<0?'':data.captions[i].text;await p.locator('#caption').evaluate((e,t)=>e.textContent=t,text);
  const metrics=await p.evaluate(()=>{const e=document.querySelector('#caption');const range=document.createRange();range.selectNodeContents(e);return{font:getComputedStyle(e).font,box:e.getBoundingClientRect().toJSON(),text_rects:Array.from(range.getClientRects(),r=>r.toJSON()),scroll_height:e.scrollHeight,text:e.textContent};});
  assert.equal(metrics.text,text);assert(metrics.scroll_height<=78);for(const r of metrics.text_rects)assert(r.x>=70&&r.right<=1530&&r.y>=5&&r.bottom<=111);
  const name=i<0?'blank.png':`cue-${i.toString().padStart(2,'0')}.png`;await p.screenshot({path:resolve(out,name)});cards.push({file:name,sha256:hash(await readFile(resolve(out,name))),metrics});
 }
 assert.equal(requests.length,0);
 let concat='ffconcat version 1.0\n';const cuts=[];let cursor=0;
 const add=(file,seconds,start)=>{assert(seconds>=0);if(seconds===0)return;concat+=`file '${resolve(out,file)}'\nduration ${seconds.toFixed(9)}\n`;cuts.push({file,start,duration:seconds});};
 data.captions.forEach((c,i)=>{assert(c.start>=cursor);add('blank.png',c.start-cursor,cursor);add(`cue-${i.toString().padStart(2,'0')}.png`,c.end-c.start,c.start);cursor=c.end;});
 add('blank.png',duration-cursor,cursor);concat+=`file '${resolve(out,'blank.png')}'\n`;
 await writeFile(resolve(q,'caption-cards.ffconcat'),concat);await writeFile(resolve(q,'caption-render.json'),JSON.stringify({status:'PASS rendered draft caption geometry',caption_status:data.status,browser:browser.version(),duration,cards,cuts,requests,scope:'Actual Chromium rasterized authored draft text at actual PCM sentence spans. Pronunciation/word accuracy not approved; clean video remains separate. Footer overlay only; no product UI edits.'},null,2)+'\n');console.log(cards.length,'cards; actual geometry PASS; captions remain DRAFT');await ctx.close();
}finally{if(browser)await browser.close();}
