"""Publish derived media evidence while preserving actual local originals."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

P=Path(__file__).resolve().parent
W=P.parents[1]
R=W/'entrotter'
PUB=R/'evidence/submission-cli-demo'
PUB.mkdir(exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest()
for ext in ['mp4','srt','vtt']:
    shutil.copyfile(P/('deliverables/entrotter-demo-cli.'+ext),R/('submission/media/entrotter-demo-cli.'+ext))
for name,src in {
    'price-text.txt':P/'inputs/price-text.stdout',
    'account-text.txt':P/'inputs/account-text.stdout',
    'complete.json':P/'inputs/complete.stdout',
    'incomplete.json':P/'inputs/incomplete.stdout',
    'incomplete.stderr':P/'inputs/incomplete.stderr',
    'synthetic-missing-account.json':P/'inputs/synthetic-missing-account.json',
    'preserved-media.json':P/'inputs/preserved-media.json',
    'cut-list.json':P/'cut-list.json',
    'audio-caption-proof.json':P/'audio-caption-proof.json',
    'boundary-proof.json':P/'boundary-proof.json',
    'probe.json':P/'probe.json',
    'capture.json':R/'output/playwright/cli-demo/capture.json',
    'filter-graph.txt':P/'filter-graph.txt',
    **{'frame-'+n+'.png':P/('deliverables/frame-'+n+'.png') for n in ['price','account','gate','before-price','after-price','end']},
    **{'overlay-'+n+'.png':R/('output/playwright/cli-demo/'+n+'.png') for n in ['price','account','gate']},
}.items():shutil.copyfile(src,PUB/name)
helpers={}
for name in ['prepare.py','capture.mjs','render.py','check-boundaries.py','package.py']:
    b=(P/name).read_bytes()
    helpers[name]=H(b)
    (PUB/('production-'+name+'.gz')).write_bytes(gzip.compress(b,mtime=0))

# Public JSON path normalization only; full raw originals retained and hashed.
for name in ['inputs/execution.json','render-command.json']:
    b=(P/name).read_bytes()
    normal=b.replace(str(W).encode(),b'<workspace>')
    (PUB/Path(name).name).write_bytes(normal)
for name in ['encode.log','decode.log','source-audio-packets.json','target-audio-packets.json']:
    b=(P/name).read_bytes().replace(str(W).encode(),b'<workspace>')
    (PUB/(name+'.gz')).write_bytes(gzip.compress(b,mtime=0))

preserved=json.loads((P/'inputs/preserved-media.json').read_text())
for name,h in preserved.items():assert H((R/name).read_bytes())==h
manifest={
    'status':'edited_additional_review_cut',
    'duration_seconds':156.8,
    'original_recording_sources':json.loads((R/'evidence/submission-account-demo/manifest.json').read_text())['source'],
    'new_offline_sources':json.loads((P/'inputs/execution.json').read_text())['sources'],
    'new_CLI_command_exit_codes':[0,0,0,3],
    'fresh_EVM_model_archive_paid_API_uploads':False,
    'synthetic_control':'One account_data view removed, explicit timeout/error and unproven classification; content identifier resealed. No fresh historical failure claimed.',
    'audio_caption_proof':'audio-caption-proof.json',
    'boundary_proof':'boundary-proof.json',
    'decode_returncode':0,
    'decode_log_bytes':(P/'decode.log').stat().st_size,
    'preserved_prior_media_files':len(preserved),
    'original_preservation':'preserved-media.json',
    'source_helper_sha256':helpers,
    'media':{f'submission/media/entrotter-demo-cli.{e}':{'sha256':H((R/f'submission/media/entrotter-demo-cli.{e}').read_bytes()),'bytes':(R/f'submission/media/entrotter-demo-cli.{e}').stat().st_size} for e in ['mp4','vtt','srt']},
    'public_evidence_sha256':{str(f.relative_to(PUB)):H(f.read_bytes()) for f in sorted(PUB.iterdir()) if f.is_file() and f.name not in ['manifest.json','README.md','independent-review.json']},
    'local_raw_sha256':{str(f.relative_to(W)):H(f.read_bytes()) for f in sorted(P.rglob('*')) if f.is_file() and 'deliverables' not in f.parts},
    'normalization':'Public execution/render JSON and encode log replace absolute workspace prefix with <workspace>; original hashes and raw files remain retained locally. Other published outputs unchanged.',
    'attempts':[
        {'path':'failed-layout','scope':'Account33 lines overlapped footer: capture assertion1 before render; fixed account line height18. No CLI re-execution.'},
        {'path':'failed-encode','scope':'FFmpeg9 removed filter_complex_script: exit8 before encoding. Corrected argv to filter_complex with same graph.'},
        {'path':'failed-boundary','scope':'Initial unquoted select expression failed before source-frame extraction; quoted filter expression repaired. No second final render.'},
    ],
    'remaining':'Independent human main approval, supported-host delivery, human auditory review and competition submission pending; prior auditory limit retained despite unchanged audio.',
    'authoring_tool_versions':{cmd:subprocess.check_output([cmd,'-version'],stderr=subprocess.STDOUT).decode().splitlines()[0] for cmd in ['ffmpeg','ffprobe']},
}
(PUB/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'public_files':len(manifest['public_evidence_sha256']),'prior_media_preserved':len(preserved),'sha256':manifest['media']['submission/media/entrotter-demo-cli.mp4']['sha256']}))
