"""Picture-only revision: preserve original soundtrack, captions, duration and sources."""
import hashlib
import json
from pathlib import Path
import subprocess
import shutil

PROJECT = Path(__file__).resolve().parent
WORKSPACE = PROJECT.parents[1]
ROOT = WORKSPACE / "entrotter"
RAW = ROOT / "output/playwright/cli-demo"
OUT = PROJECT / "deliverables"
OUT.mkdir(exist_ok=True)
H = lambda b: hashlib.sha256(b).hexdigest()
source = ROOT / "submission/media/entrotter-demo-account.mp4"
assert H(source.read_bytes()) == "8bf4541c49aa7482bb495464c9dddd7fc689dad2b0ba1472f9c1dfd1fa7f0a07"
cut = {
    "source": "submission/media/entrotter-demo-account.mp4",
    "source_sha256": H(source.read_bytes()),
    "source_interval_seconds": [0, 156.8],
    "target_duration_seconds": 156.8,
    "geometry": {"x": 0, "y": 0, "width": 1600, "height": 762},
    "audio": "Map source 0:a:0 once, stream copy; retain every packet and timestamp",
    "captions": "Original burned captions below y=762 and VTT/SRT bytes unchanged",
    "layers": [
        {"file": "price.png", "start_frame": 1243, "end_frame_exclusive": 1472, "purpose": "Caption6: previously recorded Ethereum/Aave price case, explicitly separate32 prefix"},
        {"file": "account.png", "start_frame": 2114, "end_frame_exclusive": 2373, "purpose": "Caption9: aggregate account changes, exact units and limitations"},
        {"file": "gate.png", "start_frame": 3400, "end_frame_exclusive": 3653, "purpose": "Caption14: use same sealed account report in CLI scripts; explicit synthetic incomplete control"},
    ],
    "frame_rate": 25,
    "scope": "Edited review cut mixing viewer8aa/CLI696 original footage with actual CLI24/SDKba4 offline outputs; no fresh viewer/EVM/model/archive call",
}
for x in cut["layers"]:
    x["source_sha256"] = H((RAW / x["file"]).read_bytes())
    x["start_seconds"] = x["start_frame"] / 25
    x["end_seconds_exclusive"] = x["end_frame_exclusive"] / 25
(PROJECT / "cut-list.json").write_text(json.dumps(cut, indent=2) + "\n")
graph=[]
for n, layer in enumerate(cut["layers"], 1):
    previous = "0:v" if n == 1 else f"v{n-1}"
    graph.append(f"[{previous}][{n}:v]overlay=x=0:y=0:enable='gte(n,{layer['start_frame']})*lt(n,{layer['end_frame_exclusive']})':eof_action=repeat[v{n}]")
(PROJECT / "filter-graph.txt").write_text(';\n'.join(graph) + "\n")
target=OUT / "entrotter-demo-cli.mp4"
assert not target.exists(), "Preserve previous render; choose a new path for revisions"
argv=["ffmpeg","-nostdin","-n","-hide_banner","-i",str(source)]
for layer in cut["layers"]:
    argv += ["-loop","1","-framerate","25","-i",str(RAW / layer["file"])]
argv += ["-filter_complex",';'.join(graph),"-map","[v3]","-map","0:a:0","-c:v","libx264","-preset","medium","-crf","18","-pix_fmt","yuv420p","-c:a","copy","-t","156.8","-movflags","+faststart","-metadata","title=Entrotter exact CLI inspection — October 4 edited review cut",str(target)]
(PROJECT / "render-command.json").write_text(json.dumps(argv,indent=2) + "\n")
with (PROJECT / "encode.log").open('w') as log:
    result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
(PROJECT / "encode-exit.json").write_text(json.dumps({"returncode":result.returncode}) + "\n")
assert result.returncode == 0
for ext in ['vtt','srt']:
    shutil.copyfile(ROOT / f"submission/media/entrotter-demo-account.{ext}",OUT / f"entrotter-demo-cli.{ext}")
probe=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_format","-show_streams","-of","json",str(target)]))
probe["format"]["filename"]="submission/media/entrotter-demo-cli.mp4"
(PROJECT / "probe.json").write_text(json.dumps(probe,indent=2) + "\n")
assert float(probe["format"]["duration"]) == 156.8
assert len(probe["streams"]) == 2
v,a=probe["streams"]
assert v["codec_name"]=='h264' and (v["width"],v["height"],v["avg_frame_rate"],v["nb_frames"])==(1600,900,'25/1','3920')
assert a["codec_name"]=='aac' and a["sample_rate"]=='48000'
with (PROJECT / "decode.log").open('w') as log:
    result=subprocess.run(['ffmpeg','-nostdin','-v','error','-xerror','-i',str(target),'-f','null','-'],stdout=log,stderr=subprocess.STDOUT)
assert result.returncode == 0 and (PROJECT / "decode.log").stat().st_size == 0
for name,t in [('price',54),('account',89),('gate',141),('before-price',49.68),('after-price',58.88),('end',150)]:
    subprocess.run(['ffmpeg','-nostdin','-n','-v','error','-ss',str(t),'-i',str(target),'-frames:v','1',str(OUT / ('frame-'+name+'.png'))],check=True)
for p,h in json.loads((PROJECT / 'inputs/preserved-media.json').read_text()).items():
    assert H((ROOT / p).read_bytes()) == h
print(json.dumps({'duration':156.8,'bytes':target.stat().st_size,'sha256':H(target.read_bytes()),'decode_errors':0}))
