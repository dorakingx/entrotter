"""Targeted frame-boundary and caption-region evidence for picture-only overlays."""
import json
from pathlib import Path
import re
import subprocess

P = Path(__file__).resolve().parent
W = P.parents[1]
cut = json.loads((P / 'cut-list.json').read_text())
Q = P / 'boundaries'
Q.mkdir(exist_ok=True)
source = W / 'entrotter' / cut['source']
target = P / 'deliverables/entrotter-demo-cli.mp4'
frames = sorted({n for row in cut['layers'] for n in [row['start_frame']-1,row['start_frame'],row['end_frame_exclusive']-1,row['end_frame_exclusive']]})
select = '+'.join('eq(n,' + str(n) + ')' for n in frames)
for label, path in [('source',source),('target',target)]:
    d=Q / label
    d.mkdir(exist_ok=True)
    argv=['ffmpeg','-nostdin','-n','-v','error','-i',str(path),'-vf',"select='"+select+"'",'-fps_mode','vfr',str(d / '%02d.png')]
    with (Q / (label+'-extract.log')).open('w') as log:
        result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode==0 and len(list(d.glob('*.png')))==len(frames)
rows=[]
for index, frame in enumerate(frames,1):
    active=next((r for r in cut['layers'] if r['start_frame']<=frame<r['end_frame_exclusive']),None)
    s=Q / 'source' / f'{index:02}.png'
    t=Q / 'target' / f'{index:02}.png'
    ref=W / 'entrotter/output/playwright/cli-demo' / active['file'] if active else s
    values={}
    for region, other, crop in [('picture',ref,'crop=1600:762:0:0'),('captions',s,'crop=1600:138:0:762')]:
        argv=['ffmpeg','-nostdin','-hide_banner','-i',str(t),'-i',str(other),'-filter_complex',f'[0:v]{crop},format=yuv444p[a];[1:v]{crop},format=yuv444p[b];[a][b]ssim','-f','null','-']
        result=subprocess.run(argv,capture_output=True)
        (Q / f'{frame}-{region}.log').write_bytes(result.stderr)
        assert result.returncode==0
        matches=re.findall(rb'All:([0-9.]+)',result.stderr)
        assert len(matches)==1
        score=float(matches[0])
        assert score>0.95, (frame,region,score)
        values[region]=score
    rows.append({'frame':frame,'seconds':frame/25,'active':active['file'] if active else None,'SSIM':values})
(P / 'boundary-proof.json').write_text(json.dumps({'status':'pass','checked_frames':len(rows),'rows':rows,'scope':'All four frames around each overlay boundary; top expected-source and caption-region fidelity. Lossy reencode, not byte/pixel equality or human auditory assurance.'},indent=2)+'\n')
print(json.dumps({'frames':len(rows),'minimum_picture_SSIM':min(x['SSIM']['picture'] for x in rows),'minimum_caption_SSIM':min(x['SSIM']['captions'] for x in rows)}))
