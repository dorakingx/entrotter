// Reproducible screenshots of saved real CLI output; no simulated command entry.
import {createRequire} from 'node:module';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {createServer} from 'node:http';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const project=dirname(fileURLToPath(import.meta.url));
const workspace=resolve(project,'../..');
const require=createRequire(resolve(workspace,'entrotter.github.io/package.json'));
const {chromium}=require('playwright');
const out=resolve(workspace,'entrotter/output/playwright/cli-demo');
await mkdir(out,{recursive:true});
const allowed=new Set(['/price.html','/account.html','/gate.html']);
const requests=[], served={}, errors=[];
const server=createServer(async(req,res)=>{
  requests.push({url:req.url,method:req.method});
  if(req.method!=='GET'||!allowed.has(req.url)){res.writeHead(404);res.end();return;}
  const bytes=await readFile(resolve(project,'inputs',req.url.slice(1)));
  served[req.url]=createHash('sha256').update(bytes).digest('hex');
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(bytes);
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser;
try{
  browser=await chromium.launch({headless:true});
  const page=await browser.newPage({viewport:{width:1600,height:762},deviceScaleFactor:1});
  page.on('pageerror',e=>errors.push(String(e)));
  await page.route('**/*',async route=>{
    const u=new URL(route.request().url());
    assert.equal(u.origin,`http://127.0.0.1:${server.address().port}`);
    assert.equal(route.request().method(),'GET');
    await route.continue();
  });
  const checks=[];
  for(const name of ['price','account','gate']){
    await page.goto(`http://127.0.0.1:${server.address().port}/${name}.html`);
    await page.locator('header').waitFor();
    await page.evaluate(()=>document.fonts.ready);
    if(name!=='gate'){
      const text=await page.locator('#actual-output').textContent();
      assert.equal(text,(await readFile(resolve(project,'inputs',name==='price'?'price-text.stdout':'account-text.stdout'))).toString());
    }
    const bounds=await page.locator('.panel').boundingBox();
    const textBounds=await page.locator('pre').evaluateAll(nodes=>nodes.map(n=>{
      const r=n.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,scrollWidth:n.scrollWidth,clientWidth:n.clientWidth};
    }));
    const footer=await page.locator('footer').boundingBox();
    assert(bounds.y+bounds.height<footer.y,JSON.stringify({name,bounds,footer,textBounds}));
    for(const r of textBounds){assert(r.x>=0&&r.x+r.width<=1600);assert(r.y+r.height<footer.y);assert(r.scrollWidth<=r.clientWidth);}
    await page.screenshot({path:resolve(out,name+'.png')});
    checks.push({name,bounds,textBounds,footer,body:await page.locator('body').innerText()});
  }
  assert.equal(errors.length,0);
  await writeFile(resolve(out,'capture.json'),JSON.stringify({browser:browser.version(),requests,served_sha256:served,errors,checks,scope:'Saved actual offline stdout/exit displays, not continuous terminal typing or fresh EVM'},null,2)+'\n');
  console.log(JSON.stringify({screens:checks.length,requests:requests.length,errors:errors.length}));
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
