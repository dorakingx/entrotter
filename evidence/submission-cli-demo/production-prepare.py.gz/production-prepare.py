"""Local one-off media producer: actual offline CLI outputs, never staged success."""
import hashlib
import html
import json
import os
from pathlib import Path
import subprocess

WORKSPACE = Path(__file__).resolve().parents[2]
PROJECT = Path(__file__).resolve().parent
ROOT = WORKSPACE / "entrotter"
CLI = WORKSPACE / ".worktrees/cli-bounded"
SDK = WORKSPACE / "sdk-python"
ENGINE = WORKSPACE / ".worktrees/engine-consumer-observations"
OUT = PROJECT / "inputs"
OUT.mkdir(exist_ok=True)
H = lambda b: hashlib.sha256(b).hexdigest()
PIN = {
    "coordination": "5bee12dd794200b90a22b70522e943b6c8c879b3",
    "cli": "24bbb916555ef18528300f995e127d50ff29167e",
    "sdk": "ba4af512784119f23b6dea63fd24c7f5d1fdde44",
    "engine": "88c6cd0d00f466ed7e870bd57c118aa50984f8b1",
}
for name, repo in [("coordination", ROOT), ("cli", CLI), ("sdk", SDK), ("engine", ENGINE)]:
    assert subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"]).decode().strip() == PIN[name]

preserved = {str(p.relative_to(ROOT)): H(p.read_bytes()) for p in sorted((ROOT / "submission/media").iterdir()) if p.is_file()}
(OUT / "preserved-media.json").write_text(json.dumps(preserved, indent=2) + "\n")
python = CLI / ".quality/observed-text/installed-venv/bin/python"
env = os.environ.copy()
env.pop("PYTHONPATH", None)
origins_code = """import importlib.util, json, pathlib
assert importlib.util.find_spec('entrotter_engine') is None
rows={}
for package in ['entrotter_cli','entrotter_sdk']:
    base=pathlib.Path(importlib.util.find_spec(package).origin).parent
    for p in sorted(base.glob('*.py')):
        import hashlib
        rows[package+'/'+p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'origin':str(p)}
print(json.dumps(rows,sort_keys=True))
"""
origins = subprocess.run([str(python), "-I", "-c", origins_code], env=env, capture_output=True, timeout=15)
(OUT / "installed-origins.stdout").write_bytes(origins.stdout)
(OUT / "installed-origins.stderr").write_bytes(origins.stderr)
assert origins.returncode == 0 and origins.stderr == b""
modules = json.loads(origins.stdout)
assert len(modules) == 13
for rel, data in modules.items():
    repo = CLI if rel.startswith("entrotter_cli/") else SDK
    raw = (repo / "src" / rel).read_bytes()
    git_raw = subprocess.check_output(["git", "-C", str(repo), "show", "HEAD:src/" + rel])
    assert H(raw) == H(git_raw) == data["sha256"]

price_src = ENGINE / "evidence/owned-consumer-observations/historical-32/observed-trace.json"
account_src = CLI / "tests/data/aave-account-position13.json"
assert price_src.read_bytes() == (CLI / "tests/data/observed-price32.json").read_bytes()
assert H(price_src.read_bytes()) == "7010848300c353310fb78dab7f377daea4226633e49af3c1a384bcb3a579ba9d"
assert H(account_src.read_bytes()) == "cd96e04c837fa1dcc6b6cf009d58adffe3ffdaebc9fbd5b3b900d71cd2912978"
(OUT / "price32.json").write_bytes(price_src.read_bytes())
(OUT / "account13.json").write_bytes(account_src.read_bytes())

# Same explicit synthetic missing-account control as the reviewed CLI test.
row = json.loads(account_src.read_bytes())
row["observations"][1].update(raw=None, errors=[{
    "query": "account_data", "category": "rpc_error",
    "diagnostics": {"code": "timeout", "method": "eth_call"},
}])
row["classification"].update(
    complete_account_views=False, unproven_reasons=["incomplete_account_views"],
    baseline=None, candidate=None,
    differences={k: None for k in row["classification"]["differences"]},
    base_unit=None, baseline_health_status="unproven", candidate_health_status="unproven",
)
body = {k: v for k, v in row.items() if k != "artifact_id"}
row["artifact_id"] = H(json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode())
(OUT / "synthetic-missing-account.json").write_text(json.dumps(row, indent=2, allow_nan=False) + "\n")

guard = """import sys, runpy
from unittest.mock import patch
from entrotter_sdk import Client
sys.modules['entrotter_engine']=None
with patch('socket.socket',side_effect=AssertionError('No network')), patch.object(Client,'_request',side_effect=AssertionError('No HTTP')), patch('entrotter_cli.main.ExportBudget',side_effect=AssertionError('No execution/export')):
    sys.argv=['entrotter_cli']+sys.argv[1:]
    runpy.run_module('entrotter_cli',run_name='__main__')
"""
commands = []
def invoke(label, args, expected):
    argv = [str(python), "-I", "-c", guard, *args]
    proc = subprocess.run(argv, cwd=OUT, env=env, capture_output=True, timeout=15)
    (OUT / (label + ".stdout")).write_bytes(proc.stdout)
    (OUT / (label + ".stderr")).write_bytes(proc.stderr)
    record = {"label": label, "args": args, "actual_argv": argv, "cwd": str(OUT),
              "returncode": proc.returncode, "stdout_sha256": H(proc.stdout),
              "stderr_sha256": H(proc.stderr), "timeout_seconds": 15}
    commands.append(record)
    (OUT / "execution.json").write_text(json.dumps({"sources": PIN, "modules": modules, "commands": commands}, indent=2) + "\n")
    assert proc.returncode == expected
    return proc

price = invoke("price-text", ["observed-inspect", "price32.json", "--format", "text"], 0)
account = invoke("account-text", ["position-inspect", "account13.json", "--format", "text"], 0)
assert price.stdout == (CLI / "tests/data/observed-price32.txt").read_bytes() and not price.stderr
assert account.stdout == (CLI / "tests/data/aave-account-position13.txt").read_bytes() and not account.stderr
complete = invoke("complete", ["position-verify", "account13.json", "--require-complete"], 0)
incomplete = invoke("incomplete", ["position-verify", "synthetic-missing-account.json", "--require-complete"], 3)
assert H(complete.stdout) == "85121fd50da2ba2290a5c4bbb820efd02dcb3b6848f6718d90959878ecde552f" and not complete.stderr
assert incomplete.stderr == b"Incomplete recorded comparison: incomplete_account_views\n"
c = json.loads(complete.stdout)
i = json.loads(incomplete.stdout)
assert c["integrity_verified"] and c["classification"]["complete_account_views"]
assert i["integrity_verified"] and not i["classification"]["complete_account_views"]
assert all(v is None for v in i["classification"]["differences"].values())

CSS = """*{box-sizing:border-box}html,body{margin:0;width:1600px;height:762px;overflow:hidden;background:#100c1b;color:#f7f4ff;font-family:Arial,Helvetica,sans-serif}header{height:60px;padding:0 36px;display:flex;align-items:center;gap:22px;border-bottom:1px solid #342743;background:#120d1e}header strong{font-size:24px}header span{font-size:17px;color:#c4b3e3}header small{margin-left:auto;font-size:15px;color:#bbb0cb}.panel{margin:14px 32px 0;padding:14px 22px 12px;border:1px solid #453659;border-radius:12px;background:#161020}.command{color:#b994ff;font:19px/24px Menlo,monospace;margin:0 0 10px}pre{margin:0;white-space:pre;font:19px/20px Menlo,monospace;color:#ded7e9}.key{color:#98e2b4}.alert{color:#f0c77d}footer{position:absolute;bottom:9px;left:34px;right:34px;color:#c4b3d6;font-size:16px}.gate .panel{padding:26px 30px}.gate pre{font-size:25px;line-height:40px}.gate .command{font-size:23px;line-height:36px;margin-bottom:8px}.gate h2{font-size:24px;font-weight:normal;color:#c4b3e3;margin:10px 0 14px}.gate section+section{border-top:1px solid #453659;margin-top:25px;padding-top:18px}"""
def page(label, command, output, name):
    lines = []
    for line in output.decode().splitlines():
        style = "key" if any(x in line for x in ["Candidate - baseline (USD):", "Available borrowing (USD)", "Health factor", "comparison: Complete"]) else ""
        lines.append('<span class="' + style + '">' + html.escape(line) + '</span>')
    doc = '<!doctype html><html lang="en"><meta charset="utf-8"><style>' + CSS + '</style>'
    doc += '<header><strong>Entrotter</strong><span>' + label + '</span><small>CLI 24bbb91 · SDK ba4af51 · offline</small></header>'
    if name == 'account':
        doc += '<style>#actual-output{font-size:18px;line-height:18px}</style>'
    doc += '<div class="panel"><div class="command">$ ' + html.escape(command) + '</div><pre id="actual-output">' + '\n'.join(lines) + '\n</pre></div>'
    doc += '<footer>Actual CLI stdout · recorded evidence, no new historical execution · synthetic narration retained</footer></html>'
    (OUT / (name + '.html')).write_text(doc)

page("RECORDED PRICE CASE · 32 TRANSACTIONS", "entrotter observed-inspect price32.json --format text", price.stdout, "price")
page("RECORDED ACCOUNT CASE · 13 TRANSACTIONS", "entrotter position-inspect account13.json --format text", account.stdout, "account")
gate_lines = [
    ("Original recorded account", "entrotter position-verify account13.json --require-complete > complete.json", complete, c),
    ("Synthetic control · one account view removed", "entrotter position-verify synthetic-missing-account.json --require-complete > incomplete.json", incomplete, i),
]
doc = '<!doctype html><html lang="en"><meta charset="utf-8"><style>' + CSS + '</style><body class="gate"><header><strong>Entrotter</strong><span>USE THE SAME ACCOUNT RECORD IN SCRIPTS</span><small>CLI 24bbb91 · SDK ba4af51 · offline</small></header><div class="panel">'
for title, command, proc, summary in gate_lines:
    shown = f'exit: {proc.returncode}\nintegrity_verified: {str(summary["integrity_verified"]).lower()}\ncomplete_account_views: {str(summary["classification"]["complete_account_views"]).lower()}\n'
    if proc.stderr:
        shown += proc.stderr.decode()
    doc += '<section><h2>' + html.escape(title) + '</h2><div class="command">$ ' + html.escape(command) + '</div><pre class="' + ('alert' if proc.returncode else 'key') + '">' + html.escape(shown) + '</pre></section>'
doc += '</div><footer>Actual exit/stderr; displayed fields extracted from saved full JSON · integrity alone does not prove a complete comparison</footer></body></html>'
(OUT / "gate.html").write_text(doc)
print(json.dumps({"commands": len(commands), "returns": [x["returncode"] for x in commands], "preserved_media": len(preserved), "installed_modules": len(modules)}))
